package com.mypersonalaiai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var commandInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var statusText: TextView
    private val speechRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFFF7F8FC.toInt())
        }

        val title = TextView(this).apply {
            text = "My personal ai"
            textSize = 28f
            setTextColor(0xFF172554.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, match(WRAP, 64))

        val subtitle = TextView(this).apply {
            text = "আপনার বাংলা পার্সোনাল অ্যাসিস্ট্যান্ট"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF334155.toInt())
        }
        root.addView(subtitle, match(WRAP, 48))

        phoneInput = EditText(this).apply {
            hint = "ইমনের WhatsApp নম্বর (দেশের কোডসহ)"
            textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setSingleLine(true)
        }
        root.addView(phoneInput, match(WRAP, 58))

        commandInput = EditText(this).apply {
            hint = "বলুন বা লিখুন: ইমনকে Hi পাঠাও"
            textSize = 16f
            minLines = 2
            gravity = Gravity.TOP
        }
        root.addView(commandInput, match(WRAP, 100))

        val voiceButton = Button(this).apply {
            text = "🎙 বাংলায় কথা বলুন"
            setOnClickListener { startVoiceInput() }
        }
        root.addView(voiceButton, match(WRAP, 56))

        val actionButton = Button(this).apply {
            text = "WhatsApp-এ মেসেজ প্রস্তুত করুন"
            setOnClickListener { prepareWhatsAppMessage() }
        }
        root.addView(actionButton, match(WRAP, 60))

        statusText = TextView(this).apply {
            text = "শুরু করতে নম্বর ও নির্দেশ লিখুন।"
            textSize = 15f
            setTextColor(0xFF475569.toInt())
            setPadding(4, 18, 4, 8)
        }
        root.addView(statusText, match(WRAP, WRAP))

        val note = TextView(this).apply {
            text = "নিরাপত্তা: এই প্রথম সংস্করণে WhatsApp খুলে মেসেজটি প্রস্তুত করা হবে। পাঠানোর আগে WhatsApp-এ প্রাপক ও লেখা যাচাই করে Send চাপুন।"
            textSize = 13f
            setTextColor(0xFF64748B.toInt())
        }
        root.addView(note, match(WRAP, WRAP))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "আপনার নির্দেশ বলুন")
        }
        try {
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            Toast.makeText(this, "এই ফোনে ভয়েস ইনপুট সেবা পাওয়া যাচ্ছে না।", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!results.isNullOrEmpty()) {
                commandInput.setText(results[0])
                statusText.text = "আপনার নির্দেশ: ${results[0]}"
            }
        }
    }

    private fun prepareWhatsAppMessage() {
        val rawPhone = phoneInput.text.toString().trim()
        val command = commandInput.text.toString().trim()
        if (rawPhone.isBlank()) {
            phoneInput.error = "WhatsApp নম্বর লিখুন, যেমন 8801XXXXXXXXX"
            return
        }
        if (command.isBlank()) {
            commandInput.error = "আগে নির্দেশ লিখুন বা বলুন"
            return
        }

        // MVP command parser: asks for the intended message rather than guessing.
        val message = when {
            command.contains("হাই", ignoreCase = true) ||
            command.contains("hi", ignoreCase = true) -> "Hi"
            command.contains("হ্যালো", ignoreCase = true) ||
            command.contains("hello", ignoreCase = true) -> "Hello"
            else -> command
        }

        val phone = rawPhone.filter { it.isDigit() }
        val encoded = URLEncoder.encode(message, "UTF-8")
        val uri = Uri.parse("https://wa.me/$phone?text=$encoded")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            statusText.text = "WhatsApp-এ মেসেজ প্রস্তুত করা হচ্ছে। পাঠানোর আগে যাচাই করুন।"
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "WhatsApp খোলা যায়নি। WhatsApp ইনস্টল আছে কি না দেখুন।", Toast.LENGTH_LONG).show()
        }
    }

    private fun match(width: Int, height: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(width, height).apply { bottomMargin = 10 }

    companion object {
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
